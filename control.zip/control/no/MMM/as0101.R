#!/usr/bin/env Rscript
library(rlist)
setwd('Desktop/model_rcpp_hpc_OneDrive'); output_dir <- "Output_no_extinction"


sim_nam <- "as0101MMM" # an identifier for this series of simulations
source("control_common.R") 