#!/usr/bin/env Rscript
library(rlist)
setwd('Desktop/model_rcpp_hpc_OneDrive')

output_dir <- "Output_no_extinction"

source("calc_trait_fluctuation.R")